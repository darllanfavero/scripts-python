import logging
import os
from http import HTTPStatus

from flask import Flask, request, send_file

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@app.before_request
def log_request():
    print(f"Received {request.method} request to {request.url}")
    print("Headers:", dict(request.headers))
    print("Body:", request.get_data())


@app.route('/lic', methods=['POST'])
def handle_lic():
    file_path = os.path.join(os.getcwd(), "lic.cr")
    if not os.path.exists(file_path):
        print("File not found:", file_path)
        return "File not found", HTTPStatus.NOT_FOUND
    return send_file(file_path, as_attachment=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5454)
