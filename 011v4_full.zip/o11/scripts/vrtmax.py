#!/usr/bin/env python3
import json
import logging
import os
import sys

import requests
from jsonpath_ng.ext import parse
from pywidevine import PSSH, Cdm, Device

import o11
from vrtmax.tokenresolver import TokenResolver

CACHE_DIR = os.environ.get('CACHE_DIR', '/tmp')
logging.basicConfig(filename=os.path.join(CACHE_DIR, 'vrtmax.log'), filemode='a', level=logging.DEBUG)
_LOGGER = logging.getLogger(__name__)


def _load_token():
    tr = TokenResolver()
    return tr.get_playertoken()


def channels():
    """ Return a list of channels """

    channels = []

    json_data = {
        "query": """
query Page($pageId: ID!, $lazyItemCount: Int = 10, $after: ID, $before: ID, $componentCount: Int = 5, $componentAfter: ID) {
  page(id: $pageId) {
    ... on IIdentifiable {
      objectId
    }
    ... on IPage {
      id
      permalink
      title
      header {
        title
      }
      ...paginatedComponents
    }
  }
}
fragment paginatedComponents on IPage {
  paginatedComponents(first: $componentCount, after: $componentAfter) {
    edges {
      node {
        ... on IIdentifiable {
          objectId
        }
        ... on PaginatedTileList {
          ...paginatedTileListFragment
        }
        ... on StaticTileList {
          ...staticTileListFragment
        }
      }
    }
  }
}
fragment staticTileListFragment on StaticTileList {
  __typename
  objectId
  listId
  title
  description
  tileContentType
  tileOrientation
  displayType
  expires
  tileVariant
  sort {
    icon
    order
    title
    __typename
  }
  actionItems {
    ...actionItemFragment
    __typename
  }
  items {
    ...tileFragment
    __typename
  }
}
fragment actionItemFragment on ActionItem {
  __typename
  objectId
  accessibilityLabel
  action {
    ...actionFragment
    __typename
  }
  active
  mode
  objectId
  title
}
fragment actionFragment on Action {
  ... on LiveWatchAction {
    streamId
    livestreamPageLink
    startDate
    startOver
    endDate
  }
}
fragment tileFragment on Tile {
  ... on IIdentifiable {
    __typename
    objectId
  }
  ... on ITile {
    description
    title
    active
    action {
      __typename
      ... on LinkAction {
        link
        linkType
        __typename
      }
    }
    __typename
  }
  ... on LivestreamTile {
    description
    __typename
  }
}
fragment paginatedTileListFragment on PaginatedTileList {
  __typename
  objectId
  listId
  displayType
  expires
  tileVariant
  paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
    __typename
    edges {
      __typename
      cursor
      node {
        __typename
        ...tileFragment
      }
    }
  }
  sort {
    icon
    order
    title
    __typename
  }
  tileContentType
  tileOrientation
  title
  description
}
""",
        "operationName": "Page",
        "variables": {
            "pageId": "/vrtmax/kijk/",
            "componentCount": 4,
            "componentAfter": ""
        }
    }
    response = requests.post('https://www.vrt.be/vrtnu-api/graphql/public/v1', headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0',
        'Accept': 'application/graphql+json, application/json',
        'content-type': 'application/json',
        'x-vrt-client-name': 'WEB',
        'x-vrt-client-version': '1.5.5',
        'x-vrt-zone': 'default',
    }, json=json_data)

    jsonpath_expr = parse(r'$..items[?(@.action.linkType=="livestream")]')
    for match in jsonpath_expr.find(response.json()):
        page_id = match.value.get('action').get('link').rstrip('/') + '.model.json'

        json_data = {
            "query": """
query Livestream($pageId: ID!, $miniQuery: Boolean = false) {
  page(id: $pageId) {
    ... on IIdentifiable {
      __typename
      objectId
    }
    ... on IPage @skip(if: $miniQuery) {
      title
      brand
      permalink
    }
    ... on AudioLivestreamPage {
      description
      player {
        ...playerFragment
      }
    }
    ... on LivestreamPage {
      description
      player {
        ...playerFragment
      }
    }
  }
}
fragment playerFragment on MediaPlayer {
  __typename
  objectId
  expires
  sportBuffStreamId
  subtitle
  title
  watchAction {
    ... on LiveWatchAction {
      streamId
      pageLink: livestreamPageLink
      startDate
    }
  }
}
""",
            "operationName": "Livestream",
            "variables": {
                "pageId": page_id
            }
        }
        response = requests.post('https://www.vrt.be/vrtnu-api/graphql/public/v1', headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0',
            'Accept': 'application/graphql+json, application/json',
            'content-type': 'application/json',
            'x-vrt-client-name': 'WEB',
            'x-vrt-client-version': '1.5.5',
            'x-vrt-zone': 'default',
        }, json=json_data)

        livepage = response.json()

        channels.append({
            'id': livepage.get('data').get('page').get('player').get('watchAction').get('streamId'),
            'name': livepage.get('data').get('page').get('title'),
        })

    output_channels = []
    for c in channels:
        output_channels.append({
            "Name": c.get('name'),
            "Mode": "live",
            "SessionManifest": True,
            "ManifestScript": f"channel={c.get('id')}",
            "CdmType": "widevine",
            "CdmMode": "external",
            "UseCdm": True,
            "Cdm": f"channel={c.get('id')}",
            "Video": "best",
            "Subtitles": "all",
            "OnDemand": True,
            "SpeedUp": True,
            "Autostart": False,
        })

    return {
        "Channels": output_channels,
    }


def events():
    """ Return a list of events """
    return {
        "Events": []
    }


def manifest(channel: str) -> dict:
    """ Return manifest info of the specified channel """
    # Login and get tokens
    player_token = _load_token()

    # Get stream info
    response = requests.get(f'https://media-services-public.vrt.be/media-aggregator/v2/media-items/{channel}', params={
        'vrtPlayerToken': player_token,
        'client': 'vrtnu-web@PROD',
    })
    response.raise_for_status()
    data = response.json()

    # Get url with type mpeg_dash
    url = next((x['url'] for x in data['targetUrls'] if x['type'] == 'mpeg_dash'), None)
    if url is None:
        raise Exception('No mpeg_dash url found')

    return {
        "ManifestUrl": url,
        "Headers": {
            "Manifest": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            },
            "Media": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            }
        }
        # "Heartbeat": {
        #     "Url": '',
        #     "Params": '',
        #     "PeriodMs": 5 * 60 * 1000
        # }
    }


def cdm(channel, drm, cdm, challenge, pssh) -> dict:
    """ Return the keys for the specified channel """
    # Login and get tokens
    player_token = _load_token()

    # Get stream info
    response = requests.get(f'https://media-services-public.vrt.be/media-aggregator/v2/media-items/{channel}', params={
        'vrtPlayerToken': player_token,
        'client': 'vrtnu-web@PROD',
    })
    response.raise_for_status()
    data = response.json()

    license_url = 'https://widevine-proxy.drm.technology/proxy'
    license_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    }

    # load device
    device = Device.load(o11.get_cdm())

    # load cdm
    cdm = Cdm.from_device(device)

    # open cdm session
    session_id = cdm.open()

    # get license challenge
    challenge = cdm.get_license_challenge(session_id, PSSH(pssh))
    license_data = {
        'drm_info': list(challenge),
        'token': data.get('drm')
    }

    # send license challenge
    licence = requests.post(license_url, json=license_data, headers=license_headers)
    licence.raise_for_status()

    # parse license challenge
    cdm.parse_license(session_id, licence.content)

    # obtain keys
    keys = cdm.get_keys(session_id)

    # close session, disposes of session data
    cdm.close(session_id)

    return {key.kid.hex: key.key.hex() for key in keys}


def heartbeat(url, params):
    return {}


def parse_params(params, name, default=""):
    for p in params:
        if p.split("=")[0] == name and len(p.split("=")) >= 2:
            return p[len(p.split("=")[0]) + 1:]
    return default


if __name__ == '__main__':
    bind = parse_params(sys.argv, 'bind')
    doh = parse_params(sys.argv, 'doh')
    proxy = parse_params(sys.argv, 'proxy')

    o11Session = o11.session(bind=bind, proxy=proxy)
    req = o11Session.get_session()
    if doh:
        o11.dns(doh)

    action = parse_params(sys.argv, 'action')
    if action == "manifest":
        # Manifest script: action=manifest
        output = manifest(
            channel=parse_params(sys.argv, 'channel')
        )
        print(json.dumps(output, indent=2))

    elif action == "cdm":
        # Cdm script: action=cdm drm=[widevine or playready] cdm=[internal or external] challenge=[drm challenger] pssh=[pssh used to extract needed keys]
        output = cdm(
            channel=parse_params(sys.argv, 'channel'),
            drm=parse_params(sys.argv, 'drm'),
            cdm=parse_params(sys.argv, 'cdm'),
            challenge=parse_params(sys.argv, 'challenge'),
            pssh=parse_params(sys.argv, 'pssh')
        )

        for kid, key in output.items():
            print(f"{kid}:{key}")

    elif action == "events":
        # Events: action=events
        output = events()
        print(json.dumps(output, indent=2))

    elif action == "channels":
        # Channels: action=channels
        output = channels()
        print(json.dumps(output, indent=2))

    elif action == "heartbeat":
        # Heartbeat: action=heartbeat heartbeaturl=[heartbeat url returned by manifest script] heartbeatparams=[heartbeat parms returned by manifest script]
        output = heartbeat(
            url=o11.parse_params(sys.argv, 'heartbeaturl'),
            params=o11.parse_params(sys.argv, 'heartbeatparams')
        )
        print(json.dumps(output, indent=2))

    else:
        print("Invalid action: " + action)
        sys.exit()
