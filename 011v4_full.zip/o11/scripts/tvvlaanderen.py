#!/usr/bin/env python3
import json
import logging
import os
import sys

import requests
from pywidevine import PSSH, Cdm, Device

import o11
from tvvlaanderen.asset import AssetApi
from tvvlaanderen.auth import AuthApi

CACHE_DIR = os.environ.get('CACHE_DIR', '/tmp')
logging.basicConfig(filename=os.path.join(CACHE_DIR, 'tvvlaanderen.log'), filemode='a', level=logging.DEBUG)
_LOGGER = logging.getLogger(__name__)


def _load_token():
    username = o11.parse_params(sys.argv, 'username') or o11.parse_params(sys.argv, 'user')
    password = o11.parse_params(sys.argv, 'password')
    api = AuthApi(username, password, 'tvv', os.path.join(CACHE_DIR, 'tvvlaanderen.tokens'))
    api.login()
    return api


def login():
    """ Login to the service """
    _load_token()
    return "logged in successfully"

def channels():
    """ Return a list of channels """
    token = _load_token()
    api = AssetApi(token)

    channels = api.get_channels()
    output_channels = []
    for c in channels:
        output_channels.append({
            "Name": c.title,
            "Mode": "live",
            "SessionManifest": True,
            "ManifestScript": f"channel={c.uid}",
            "CdmType": "widevine",
            "CdmMode": "external",
            "UseCdm": True,
            "Cdm": f"channel={c.uid}",
            "Video": "best",
            "Subtitles": "all",
            "OnDemand": True,
            "SpeedUp": True,
            "Autostart": False,
        })

    return {
        "Channels": output_channels,
    }


def events():
    """ Return a list of events """
    return {
        "Events": []
    }


def manifest(channel: str) -> dict:
    """ Return manifest info of the specified channel """
    token = _load_token()
    api = AssetApi(token)

    stream_info = api.get_stream(channel)
    return {
        "ManifestUrl": stream_info.url,
        "Headers": {
            "Manifest": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            },
            "Media": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            }
        }
        # "Heartbeat": {
        #     "Url": '',
        #     "Params": '',
        #     "PeriodMs": 5 * 60 * 1000
        # }
    }


def cdm(channel, drm, cdm, challenge, pssh) -> dict:
    """ Return the keys for the specified channel """
    token = _load_token()
    api = AssetApi(token)

    stream_info = api.get_stream(channel)

    license_url = stream_info.drm_license_url
    license_headers = {
        'Content-Type': 'application/octet-stream',
    }

    # load device
    device = Device.load(o11.get_cdm())

    # load cdm
    cdm = Cdm.from_device(device)

    # open cdm session
    session_id = cdm.open()

    # get license challenge
    challenge = cdm.get_license_challenge(session_id, PSSH(pssh))

    # send license challenge
    licence = requests.post(license_url, data=challenge, headers=license_headers)
    licence.raise_for_status()

    # parse license challenge
    cdm.parse_license(session_id, licence.content)

    # obtain keys
    keys = cdm.get_keys(session_id)

    # close session, disposes of session data
    cdm.close(session_id)

    return {key.kid.hex: key.key.hex() for key in keys}


def heartbeat(url, params):
    return {}


if __name__ == '__main__':
    bind = o11.parse_params(sys.argv, 'bind')
    doh = o11.parse_params(sys.argv, 'doh')
    proxy = o11.parse_params(sys.argv, 'proxy')

    o11Session = o11.session(bind=bind, proxy=proxy)
    req = o11Session.get_session()
    if doh:
        o11.dns(doh)

    action = o11.parse_params(sys.argv, 'action')
    if action == "login":
        # Manifest script: action=login
        output = login()
        print(output, file=sys.stderr)

    elif action == "manifest":
        # Manifest script: action=manifest
        output = manifest(
            channel=o11.parse_params(sys.argv, 'channel')
        )
        print(json.dumps(output, indent=2))

    elif action == "cdm":
        # Cdm script: action=cdm drm=[widevine or playready] cdm=[internal or external] challenge=[drm challenger] pssh=[pssh used to extract needed keys]
        output = cdm(
            channel=o11.parse_params(sys.argv, 'channel'),
            drm=o11.parse_params(sys.argv, 'drm'),
            cdm=o11.parse_params(sys.argv, 'cdm'),
            challenge=o11.parse_params(sys.argv, 'challenge'),
            pssh=o11.parse_params(sys.argv, 'pssh')
        )

        for kid, key in output.items():
            print(f"{kid}:{key}")

    elif action == "events":
        # Events: action=events
        output = events()
        print(json.dumps(output, indent=2))

    elif action == "channels":
        # Channels: action=channels
        output = channels()
        print(json.dumps(output, indent=2))

    elif action == "heartbeat":
        # Heartbeat: action=heartbeat heartbeaturl=[heartbeat url returned by manifest script] heartbeatparams=[heartbeat parms returned by manifest script]
        output = heartbeat(
            url=o11.parse_params(sys.argv, 'heartbeaturl'),
            params=o11.parse_params(sys.argv, 'heartbeatparams')
        )
        print(json.dumps(output, indent=2))

    else:
        print("Invalid action: " + action, file=sys.stderr)
        sys.exit()
