# -*- coding: utf-8 -*-
""" VTM GO API """

from __future__ import absolute_import, division, unicode_literals

import json
import logging

from . import API_ENDPOINT, LiveChannel, LiveChannelEpg, util

_LOGGER = logging.getLogger(__name__)

import dateutil.parser


class ApiUpdateRequired(Exception):
    """ Is thrown when an API update is required. """


class VtmGo:
    """ VTM GO API """

    def __init__(self, tokens):
        """ Initialise object
        :param resources.lib.vtmgo.vtmgoauth.AccountStorage token:       An authenticated token.
        """
        self._tokens = tokens

    def get_live_channels(self) -> list[LiveChannel]:
        """ Get a list of all the live tv channels.
        :rtype list[LiveChannel]
        """
        response = util.http_get(API_ENDPOINT + '/VTM_GO/live',
                                 token=self._tokens.get('access_token') if self._tokens else None,
                                 profile=self._tokens.get('profile') if self._tokens else None)
        info = json.loads(response.text)

        channels = []
        for item in info.get('channels'):
            epg = []
            for item_epg in item.get('broadcasts', []):
                epg.append(LiveChannelEpg(
                    title=item_epg.get('name'),
                    start=dateutil.parser.parse(item_epg.get('startsAt')),
                    end=dateutil.parser.parse(item_epg.get('endsAt')),
                ))
            channels.append(LiveChannel(
                key=item.get('seoKey'),
                channel_id=item.get('channelId'),
                logo=item.get('channelLogoUrl'),
                background=item.get('channelPosterUrl'),
                name=item.get('name'),
                epg=epg,
            ))

        return channels
