# -*- coding: utf-8 -*-
""" VTM GO Authentication API """

from __future__ import absolute_import, division, unicode_literals

import json
import logging
import uuid

import jwt
from requests import HTTPError

from o11 import get_cache, set_cache
from . import util

_LOGGER = logging.getLogger(__name__)

API_ENDPOINT = 'https://lfvp-api.dpgmedia.net'


class Profile:
    """ Defines a profile under your account. """

    def __init__(self, key=None, product=None, name=None, gender=None, birthdate=None, color=None, color2=None):
        """
        :type key: str
        :type product: str
        :type name: str
        :type gender: str
        :type birthdate: str
        :type color: str
        :type color2: str
        """
        self.key = key
        self.product = product
        self.name = name
        self.gender = gender
        self.birthdate = birthdate
        self.color = color
        self.color2 = color2

    def __repr__(self):
        return "%r" % self.__dict__


class VtmGoAuth:
    """ VTM GO Authentication API """

    def __init__(self, tokens_file):
        """ Initialise object """
        self._tokens_file = tokens_file
        self._tokens = get_cache(self._tokens_file, {})

    def authorize(self):
        """ Handle the authorization flow. """
        if self._tokens.get('auth_info') is None:
            # Create a new authorization flow
            auth_info = self.authorize_start()

            print('Please go to %s, follow the instructions and retry.' % auth_info.get('verification_uri_complete'))
            exit(1)
        else:
            auth_info = self._tokens.get('auth_info')

        auth_check = self.authorize_check(auth_info.get('device_code'))
        if auth_check.get('lfvpToken'):
            # Success
            del self._tokens['auth_info']
            self._tokens['access_token'] = auth_check.get('lfvpToken')
            set_cache(self._tokens_file, self._tokens)
            return self._tokens

        if auth_check.get('error') == 'invalid_grant':
            # Retry with a new code
            self.authorize()
            exit(1)

        print('You are still not authorized. Please go to %s, follow the instructions and retry.' % auth_info.get('verification_uri_complete'))
        exit(1)

    def authorize_start(self):
        """ Start the authorization flow. """
        response = util.http_post(
            'https://login2.vtm.be/device/authorize',
            form={
                'client_id': 'vtm-go-androidtv',
                'scope': 'openid email profile',
            },
            headers={
                'User-Agent': 'okhttp/4.12.0'
            }
        )

        auth_info = json.loads(response.text)

        self._tokens['auth_info'] = auth_info
        set_cache(self._tokens_file, self._tokens)

        return auth_info

    def authorize_check(self, device_code):
        """ Check if the authorization has been completed. """
        try:
            response = util.http_post('https://login2.vtm.be/token', form={
                'device_code': device_code,
                'client_id': 'vtm-go-androidtv',
                'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
            })
        except HTTPError as exc:
            if exc.response.status_code == 400:
                return json.loads(exc.response.text)
            raise

        # Store these tokens
        auth_info = json.loads(response.text)

        # Fetch an actual token we can use
        response = util.http_post(API_ENDPOINT + '/VTM_GO/tokens', data={
            'device': {
                'id': str(uuid.uuid4()),
                'name': 'VTM Go Addon on Kodi',
            },
            'idToken': auth_info.get('access_token'),
        })
        token_info = json.loads(response.text)

        return token_info

    def get_profiles(self):
        """ Returns the available profiles """
        response = util.http_get(API_ENDPOINT + '/VTM_GO/profiles', token=self._tokens.get('access_token'))
        result = json.loads(response.text)

        profiles = [
            Profile(
                key=profile.get('id'),
                product=profile.get('product'),
                name=profile.get('name'),
                gender=profile.get('gender'),
                birthdate=profile.get('birthDate'),
                color=profile.get('color', {}).get('start'),
                color2=profile.get('color', {}).get('end'),
            )
            for profile in result.get('profiles')
        ]

        return profiles

    def get_tokens(self):
        """ Check if we have a token based on our device code. """
        # If we have no access_token, return None
        if not self._tokens.get('access_token'):
            return None

        # Return our current token if it is still valid.
        if self.is_valid_token(self._tokens.get('access_token')) and self._tokens.get('profile'):
            return self._tokens

        # We can refresh our old token so it's valid again
        response = util.http_post(API_ENDPOINT + '/VTM_GO/tokens/refresh', data={
            'lfvpToken': self._tokens.get('access_token'),
        })
        token_info = json.loads(response.text)

        # Get JWT from reply
        self._tokens['access_token'] = token_info.get('lfvpToken')

        # We always use the main profile
        profiles = self.get_profiles()
        self._tokens['profile'] = profiles[0].key
        self._tokens['product'] = profiles[0].product
        set_cache(self._tokens_file, self._tokens)

        return self._tokens

    @classmethod
    def is_valid_token(cls, access_token):
        """ Validate the JWT to see if it's still valid.

        :rtype: boolean
        """
        if not access_token:
            # We have no token
            return False

        try:
            # Verify our token to see if it's still valid.
            decoded_jwt = jwt.decode(access_token,
                                     algorithms=['HS256'],
                                     options={'verify_signature': False, 'verify_aud': False})

            # Check expiration time
            from datetime import datetime

            import dateutil.parser
            import dateutil.tz
            exp = datetime.fromtimestamp(decoded_jwt.get('exp'), tz=dateutil.tz.gettz('Europe/Brussels'))
            now = datetime.now(dateutil.tz.UTC)
            if exp < now:
                _LOGGER.debug('JWT is expired at %s', exp.isoformat())
                return False

        except Exception as exc:  # pylint: disable=broad-except
            _LOGGER.debug('JWT is NOT valid: %s', exc)
            return False

        _LOGGER.debug('JWT is valid')
        return True
