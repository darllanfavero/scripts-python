# -*- coding: utf-8 -*-
""" VTM GO API """

from __future__ import absolute_import, division, unicode_literals

API_ENDPOINT = 'https://lfvp-api.dpgmedia.net'


class LiveChannel:
    """ Defines a tv channel that can be streamed live """

    def __init__(self, key=None, channel_id=None, name=None, logo=None, background=None, epg=None, geoblocked=False):
        """
        :type key: str
        :type channel_id: str
        :type name: str
        :type logo: str
        :type background: str
        :type epg: list[LiveChannelEpg]
        :type geoblocked: bool
        """
        self.key = key
        self.channel_id = channel_id
        self.name = name
        self.logo = logo
        self.background = background
        self.epg = epg
        self.geoblocked = geoblocked

    def __repr__(self):
        return "%r" % self.__dict__


class LiveChannelEpg:
    """ Defines a program that is broadcast on a live tv channel"""

    def __init__(self, title=None, start=None, end=None):
        """
        :type title: str
        :type start: datetime.datetime
        :type end: datetime.datetime
        """
        self.title = title
        self.start = start
        self.end = end

    def __repr__(self):
        return "%r" % self.__dict__


class ResolvedStream:
    """ Defines a stream that we can play"""

    def __init__(self, program=None, program_id=None, title=None, duration=None, url=None, license_key=None, subtitles=None, cookies=None):
        """
        :type program: str|None
        :type program_id: int|None
        :type title: str
        :type duration: str|None
        :type url: str
        :type license_key: str
        :type subtitles: list[str]
        :type cookies: dict
        """
        self.program = program
        self.program_id = program_id
        self.title = title
        self.duration = duration
        self.url = url
        self.license_key = license_key
        self.subtitles = subtitles
        self.cookies = cookies

    def __repr__(self):
        return "%r" % self.__dict__
