# -*- coding: utf-8 -*-
""" VTM GO Stream API """

from __future__ import absolute_import, division, unicode_literals

import json
import logging

from . import util

API_ENDPOINT = 'https://lfvp-api.dpgmedia.net'

_LOGGER = logging.getLogger(__name__)


class ResolvedStream:
    """ Defines a stream that we can play"""

    def __init__(self, program=None, program_id=None, title=None, duration=None, url=None, license_url=None, license_headers=None, subtitles=None,
                 cookies=None):
        """
        :type program: str|None
        :type program_id: int|None
        :type title: str
        :type duration: str|None
        :type url: str
        :type license_url: str
        :type license_headers: dict
        :type subtitles: list[str]
        :type cookies: dict
        """
        self.program = program
        self.program_id = program_id
        self.title = title
        self.duration = duration
        self.url = url
        self.license_url = license_url
        self.license_headers = license_headers
        self.subtitles = subtitles
        self.cookies = cookies

    def __repr__(self):
        return "%r" % self.__dict__


class VtmGoStream:
    """ VTM GO Stream API """

    _V6_API_KEY = 'r9EOnHOp1pPL5L4FuGzBPSIHwrQnPu5TBfW16y75'  # Android

    # _V6_API_KEY = 'jL3yNhGpDsaew9CqJrDPq2UzMrlmNVbnadUXVOET' # Web

    def __init__(self, tokens=None):
        """ Initialise object """
        self._tokens = tokens

    def get_stream(self, stream_id) -> ResolvedStream:
        """ Return a ResolvedStream based on the id.
        :param str stream_id:           ID of the stream
        :rtype: ResolvedStream
        """
        # We begin with asking the api about the stream info
        stream_tokens = self._get_stream_tokens()
        player_token = stream_tokens.get('playerToken')

        # Return video information
        video_info = self._get_video_info(stream_id, player_token)

        # Select the best stream from our stream_info.
        stream_info = self._extract_stream_from_video_info(video_info, 'dash')

        # Get published urls
        url = stream_info.get('url')
        license_url = stream_info.get('drm', {}).get('com.widevine.alpha', {}).get('licenseUrl')
        license_provider = stream_info.get('drm', {}).get('com.widevine.alpha', {}).get('provider')
        if license_provider == 'drmtoday':
            license_headers = {
                'x-dt-auth-token': stream_info.get('drm', {}).get('com.widevine.alpha', {}).get('drmtoday', {}).get('authToken'),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
                'Origin': 'https://www.vtmgo.be',
                'referer': 'https://www.vtmgo.be',
            }
        else:
            license_headers = {}

        return ResolvedStream(
            url=url,
            license_url=license_url,
            license_headers=license_headers,
            cookies=util.SESSION.cookies.get_dict()
        )

    def _get_stream_tokens(self):
        """ Get the stream info for the specified stream.
        :rtype: dict
        """
        url = API_ENDPOINT + '/VTM_GO/live'

        _LOGGER.debug('Getting stream tokens from %s', url)
        response = util.http_get(url, token=self._tokens.get('access_token'), profile=self._tokens.get('profile'))

        return json.loads(response.text)

    def _get_video_info(self, stream_id, player_token=None):
        """ Get the stream info for the specified stream.
        :param str stream_id:
        :param Optional[str] player_token:
        :rtype: dict
        """
        url = 'https://videoplayer-service.dpgmedia.net/play-config/%s' % stream_id
        _LOGGER.debug('Getting video info from %s', url)
        response = util.http_post(url,
                                  # params={
                                  #     'startPosition': '0.0',
                                  #     'autoPlay': 'true',
                                  # },
                                  data={
                                      'deviceType': 'android-tv',
                                      # 'deviceType': 'web',
                                      'zone': 'vtmgo',
                                  },
                                  headers={
                                      'Accept': 'application/json',
                                      'x-api-key': self._V6_API_KEY,
                                      'Popcorn-SDK-Version': '8',
                                      'Authorization': 'Bearer ' + player_token,
                                  })

        info = json.loads(response.text)
        return info

    @staticmethod
    def _extract_stream_from_video_info(video_info, stream_type):
        """ Extract the preferred stream details.
        :type video_info: dict
        :rtype dict
        """
        # Loop over available streams, and return the requested stream
        if video_info.get('video'):
            for stream in video_info.get('video').get('streams'):
                if stream.get('type') == stream_type:
                    return stream
        elif video_info.get('code'):
            _LOGGER.error('VTM GO Videoplayer service API error: %s', video_info.get('type'))
        raise Exception('No stream found that we can handle')
