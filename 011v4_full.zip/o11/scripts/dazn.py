#!/usr/bin/env python3
import json
import logging
import os
import sys

import o11

CACHE_DIR = os.environ.get('CACHE_DIR', '/tmp')
logging.basicConfig(filename=os.path.join(CACHE_DIR, 'dazn.log'), filemode='a', level=logging.DEBUG)
_LOGGER = logging.getLogger(__name__)

CHANNELS = {
    16: "DAZN F1 ES",
    17: "DAZN 1 DE",
    18: "DAZN 2 DE",
    # 19: "",
    # 20: "",
    # 21: "",
    22: "Sport Digital DE",
    23: "NFL+",
    24: "ZONA DAZN",
    25: "Milan TV",
    26: "MLBN EN",
    27: "Eurosport 1 DE",
    28: "Eurosport 2 DE",
    29: "Eurosport 1 IT",
    30: "Eurosport 2 IT",
    31: "Eurosport 1 ES",
    32: "Eurosport 2 ES",
    33: "INTER TV",
    # 34: "DAZN 34",
    35: "NBA TV EN",
    36: "Redbull TV",
    37: "DAZN 1 ES",
    38: "DAZN 2 ES",
    39: "Rally TV",
    40: "LA LIGA TV ES",
    # 41: "DAZN 41",
    42: "DAZN 42",
    43: "DAZN La Liga ES",
    44: "Unbeaten",
    45: "DAZN 1 EN",
    46: "Leage One Uber Eats FR",
    47: "Eleven Sport 1 NL",
    48: "Eleven Sport 1 FR",
    49: "Eleven Pro Leage NL",
    50: "Eleven Pro Leage FR",
    51: "Play Sports 1 NL",
    52: "Play Sports 2 NL",
    53: "Play Sports 3 NL",
    54: "Eleven Sports 1 PT",
    55: "Eleven Sports 2 PT",
    56: "Eleven Sports 3 PT",
    57: "Eleven Sports 4 PT",
    58: "Eleven Sports 5 PT",
    59: "Eleven Sports 6 PT",
    60: "DAZN 1 FR",

    501: "DAZN Rise",
    502: "DAZN Combat",
    503: "DAZN 503",
    504: "DAZN Fast+",
    505: "DAZN 505",
    # 506: "DAZN 506",
    507: "DAZN 507",
    508: "DAZN 508",
    509: "DAZN 509",
    510: "DAZN 510",
    511: "DAZN 511",
    # 512: "DAZN 512",
    513: "DAZN 513",
    # 514: "DAZN 514",
    515: "DAZN 515",
    516: "DAZN 516",
    # 517: "DAZN 517",
    518: "DAZN 518",
    # 519: "DAZN 519",
    520: "DAZN 520",
    521: "DAZN 521",
}


def channels():
    """ Return a list of channels """
    output_channels = []
    for i in CHANNELS.keys():

        if i > 500:
            url = "https://dcj-ac-live.cdn.indazn.com/dash/dazn-linear-%03d/stream.mpd" % i
        else:
            url = "https://dcf-fs-live-dazn-cdn.dazn.com/dash/dazn-linear-%03d/stream.mpd" % i

        output_channels.append({
            "Id": f"dazn{i:03d}",
            "Name": CHANNELS.get(i, f"DAZN {i:03d}"),
            "Mode": "live",
            "OnDemand": True,
            "Autostart": False,
            "SessionManifest": False,
            "SpeedUp": True,
            "UseCdm": False,
            "Cdm": "",
            "CdmType": "widevine",
            "CdmMode": "internal",
            "Manifest": url,
            "ManifestType": "dash",
            "Keys": [
                f"8ab47741930c476780515f9a00decb0a:7ab4b9ae5a48aa526e511a913b832769",
                f"cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec"
            ],
            "Headers": {
                "Manifest": {
                    "User-Agent": "Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) QtWebEngine/5.9.7 Chrome/56.0.2924.122 Safari/537.36 Sky_STB_ST412_2018/1.0.0 (Sky, EM150UK, )"
                },
                "Media": {
                    "User-Agent": "Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) QtWebEngine/5.9.7 Chrome/56.0.2924.122 Safari/537.36 Sky_STB_ST412_2018/1.0.0 (Sky, EM150UK, )"
                }
            }
        })

    return {
        "Channels": output_channels,
    }


def events():
    """ Return a list of events """
    return {
        "Events": []
    }


def manifest(channel: str) -> dict:
    """ Return manifest info of the specified channel """
    return {}


def cdm(channel, drm, cdm, challenge, pssh) -> dict:
    """ Return the keys for the specified channel """
    return {}


def heartbeat(url, params):
    return {}


if __name__ == '__main__':
    bind = o11.parse_params(sys.argv, 'bind')
    doh = o11.parse_params(sys.argv, 'doh')
    proxy = o11.parse_params(sys.argv, 'proxy')

    o11Session = o11.session(bind=bind, proxy=proxy)
    req = o11Session.get_session()
    if doh:
        o11.dns(doh)

    action = o11.parse_params(sys.argv, 'action')
    if action == "manifest":
        # Manifest script: action=manifest
        output = manifest(
            channel=o11.parse_params(sys.argv, 'channel')
        )
        print(json.dumps(output, indent=2))

    elif action == "cdm":
        # Cdm script: action=cdm drm=[widevine or playready] cdm=[internal or external] challenge=[drm challenger] pssh=[pssh used to extract needed keys]
        output = cdm(
            channel=o11.parse_params(sys.argv, 'channel'),
            drm=o11.parse_params(sys.argv, 'drm'),
            cdm=o11.parse_params(sys.argv, 'cdm'),
            challenge=o11.parse_params(sys.argv, 'challenge'),
            pssh=o11.parse_params(sys.argv, 'pssh')
        )

        for kid, key in output.items():
            print(f"{kid}:{key}")

    elif action == "events":
        # Events: action=events
        output = events()
        print(json.dumps(output, indent=2))

    elif action == "channels":
        # Channels: action=channels
        output = channels()
        print(json.dumps(output, indent=2))

    elif action == "heartbeat":
        # Heartbeat: action=heartbeat heartbeaturl=[heartbeat url returned by manifest script] heartbeatparams=[heartbeat parms returned by manifest script]
        output = heartbeat(
            url=o11.parse_params(sys.argv, 'heartbeaturl'),
            params=o11.parse_params(sys.argv, 'heartbeatparams')
        )
        print(json.dumps(output, indent=2))

    else:
        print("Invalid action: " + action)
        sys.exit()
