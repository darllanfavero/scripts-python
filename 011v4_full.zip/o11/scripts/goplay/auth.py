# -*- coding: utf-8 -*-
""" AUTH API """

from __future__ import absolute_import, division, unicode_literals

import logging
import time

from o11 import get_cache, set_cache
from .aws.cognito_idp import (AuthenticationException, CognitoIdp,
                              InvalidLoginException)

_LOGGER = logging.getLogger(__name__)


class AuthApi:
    """ GoPlay Authentication API """
    COGNITO_POOL_ID = 'eu-west-1_dViSsKM5Y'
    COGNITO_CLIENT_ID = '6s1h851s8uplco5h6mqh1jac8m'

    def __init__(self, tokens_file, username, password):
        """ Initialise object """
        self._tokens_file = tokens_file

        self._username = username
        self._password = password
        self._id_token = None
        self._refresh_token = None
        self._expiry = 0

        # Load tokens from cache
        tokens = get_cache(self._tokens_file)
        if tokens:
            self._id_token = tokens.get('id_token')
            self._refresh_token = tokens.get('refresh_token')
            self._expiry = int(tokens.get('expiry', 0))

    def get_token(self):
        """ Get a valid token """
        now = int(time.time())

        if self._id_token and self._expiry > now:
            # We have a valid id token in memory, use it
            _LOGGER.debug('Got an id token from memory')
            return self._id_token

        if self._refresh_token:
            # We have a valid refresh token, use that to refresh our id token
            # The refresh token is valid for 30 days. If this refresh fails, we just continue by logging in again.
            _LOGGER.debug('Getting an id token by refreshing')
            try:
                self._id_token = self._refresh(self._refresh_token)
                self._expiry = now + 3600
            except (InvalidLoginException, AuthenticationException) as exc:
                _LOGGER.error('Error logging in: %s', str(exc))
                self._id_token = None
                self._refresh_token = None
                self._expiry = 0
                # We continue by logging in with username and password

        if not self._id_token:
            # We have no tokens, or they are all invalid, do a login
            _LOGGER.debug('Getting an id token by logging in')
            id_token, refresh_token = self._authenticate(self._username, self._password)
            self._id_token = id_token
            self._refresh_token = refresh_token
            self._expiry = now + 3600

        # Store new tokens in cache
        set_cache(self._tokens_file, {
            'id_token': self._id_token,
            'refresh_token': self._refresh_token,
            'expiry': self._expiry,
        })

        return self._id_token

    @staticmethod
    def _authenticate(username, password):
        """ Authenticate with Amazon Cognito and fetch a refresh token and id token. """
        idp_client = CognitoIdp(AuthApi.COGNITO_POOL_ID, AuthApi.COGNITO_CLIENT_ID)
        return idp_client.authenticate(username, password)

    @staticmethod
    def _refresh(refresh_token):
        """ Use the refresh token to fetch a new id token. """
        idp_client = CognitoIdp(AuthApi.COGNITO_POOL_ID, AuthApi.COGNITO_CLIENT_ID)
        return idp_client.renew_token(refresh_token)
