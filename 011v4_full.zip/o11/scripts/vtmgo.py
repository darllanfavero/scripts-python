#!/usr/bin/env python3
import base64
import json
import logging
import os
import sys

import requests
from pywidevine import PSSH, Cdm, Device

import o11
from vtmgo.vtmgo import VtmGo
from vtmgo.vtmgoauth import VtmGoAuth
from vtmgo.vtmgostream import VtmGoStream

CACHE_DIR = os.environ.get('CACHE_DIR', '/tmp')
logging.basicConfig(filename=os.path.join(CACHE_DIR, 'vtmgo.log'), filemode='a', level=logging.DEBUG)
_LOGGER = logging.getLogger(__name__)


def _load_tokens():
    auth = VtmGoAuth(os.path.join(CACHE_DIR, 'vtmgo.tokens'))
    _tokens = auth.get_tokens()
    if _tokens is None:
        _tokens = auth.authorize()

    return _tokens


def channels():
    """ Return a list of channels """
    _load_tokens()  # To trigger validation of credentials
    _api = VtmGo(tokens=None)

    result = []
    for c in _api.get_live_channels():
        result.append({
            "Name": c.name,
            "Mode": "live",
            "SessionManifest": True,
            "ManifestScript": f"channel={c.channel_id}",
            "CdmType": "widevine",
            "CdmMode": "external",
            "UseCdm": True,
            "Cdm": f"channel={c.channel_id}",
            "Video": "best",
            "Subtitles": "all",
            "OnDemand": True,
            "SpeedUp": True,
            "Autostart": False,
        })

    return {
        "Channels": result,
    }


def events():
    """ Return a list of events """
    return {
        "Events": []
    }


def manifest(channel: str) -> dict:
    """ Return manifest info of the specified channel """
    _stream = VtmGoStream(tokens=_load_tokens())
    resolved_stream = _stream.get_stream(channel)

    return {
        "ManifestUrl": resolved_stream.url,
        "Headers": {
            "Manifest": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            },
            "Media": {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
            }
        }
        # "Heartbeat": {
        #     "Url": '',
        #     "Params": '',
        #     "PeriodMs": 5 * 60 * 1000
        # }
    }


def cdm(channel, drm, cdm, challenge, pssh) -> dict:
    """ Return the keys for the specified channel """
    _stream = VtmGoStream(tokens=_load_tokens())
    resolved_stream = _stream.get_stream(channel)

    # load device
    device = Device.load(o11.get_cdm())

    # load cdm
    wv_cdm = Cdm.from_device(device)

    # open cdm session
    session_id = wv_cdm.open()

    # get license challenge
    challenge = wv_cdm.get_license_challenge(session_id, PSSH(pssh))

    # send license challenge
    licence = requests.post(resolved_stream.license_url, data=challenge, headers=resolved_stream.license_headers)
    licence.raise_for_status()

    # parse license challenge
    license_json = json.loads(licence.content)
    license_data = base64.b64decode(license_json.get('license'))
    wv_cdm.parse_license(session_id, license_data)

    # obtain keys
    keys = wv_cdm.get_keys(session_id)

    # close session, disposes of session data
    wv_cdm.close(session_id)

    return {key.kid.hex: key.key.hex() for key in keys}


def heartbeat(url, params):
    return {}


if __name__ == '__main__':
    bind = o11.parse_params(sys.argv, 'bind')
    doh = o11.parse_params(sys.argv, 'doh')
    proxy = o11.parse_params(sys.argv, 'proxy')

    o11Session = o11.session(bind=bind, proxy=proxy)
    req = o11Session.get_session()
    if doh:
        o11.dns(doh)

    action = o11.parse_params(sys.argv, 'action')
    if action == "manifest":
        # Manifest script: action=manifest
        output = manifest(
            channel=o11.parse_params(sys.argv, 'channel')
        )
        print(json.dumps(output, indent=2))

    elif action == "cdm":
        # Cdm script: action=cdm drm=[widevine or playready] cdm=[internal or external] challenge=[drm challenger] pssh=[pssh used to extract needed keys]
        output = cdm(
            channel=o11.parse_params(sys.argv, 'channel'),
            drm=o11.parse_params(sys.argv, 'drm'),
            cdm=o11.parse_params(sys.argv, 'cdm'),
            challenge=o11.parse_params(sys.argv, 'challenge'),
            pssh=o11.parse_params(sys.argv, 'pssh')
        )

        for kid, key in output.items():
            print(f"{kid}:{key}")

    elif action == "events":
        # Events: action=events
        output = events()
        print(json.dumps(output, indent=2))

    elif action == "channels":
        # Channels: action=channels
        output = channels()
        print(json.dumps(output, indent=2))

    elif action == "heartbeat":
        # Heartbeat: action=heartbeat heartbeaturl=[heartbeat url returned by manifest script] heartbeatparams=[heartbeat parms returned by manifest script]
        output = heartbeat(
            url=o11.parse_params(sys.argv, 'heartbeaturl'),
            params=o11.parse_params(sys.argv, 'heartbeatparams')
        )
        print(json.dumps(output, indent=2))

    else:
        print("Invalid action: " + action)
        sys.exit()
