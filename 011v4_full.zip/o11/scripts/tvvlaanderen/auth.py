# -*- coding: utf-8 -*-
""" Solocoo Auth API """

from __future__ import absolute_import, division, unicode_literals

import datetime
import hashlib
import hmac
import json
import logging
import uuid
from hashlib import md5

import jwt

from . import SOLOCOO_API, util
from .config import TENANTS
from .exceptions import InvalidTokenException

_LOGGER = logging.getLogger(__name__)


class AccountStorage:
    """ Data storage for account info """
    # We will generate a random serial when we don't have any
    device_serial = ''
    device_name = "samsung SM-G955F"

    sso_token = ''

    # Token used to authenticate a request to the tvapi.solocoo.tv endpoint
    jwt_token = ''

    # Credentials hash
    hash = ''

    def is_valid_token(self):
        """ Validate the JWT to see if it's still valid.

        :rtype: boolean
        """
        if not self.jwt_token:
            # We have no token
            return False

        try:
            # Verify if token is still valid
            token = jwt.decode(self.jwt_token, algorithms=['HS256'], options={
                'verify_signature': False,
                'verify_aud': False,
                'verify_nbf': False,
                'verify_exp': True,
            })

            # NOTE: verify_signature=False combined with verify_exp=True doesn't work on pyjwt 2.0.0, see https://github.com/jpadilla/pyjwt/issues/599
            from calendar import timegm
            from datetime import datetime
            now = timegm(datetime.utcnow().utctimetuple())
            if int(token["exp"]) < now:
                raise Exception('Signature has expired')

        except Exception as exc:  # pylint: disable=broad-except
            _LOGGER.debug('JWT is NOT valid: %s', exc)
            return False

        return True


class AuthApi:
    """ Solocoo Auth API """

    def __init__(self, username, password, tenant, token_path):
        """ Initialisation of the class.

        :param str username:            The username of the account.
        :param str password:            The password of the account.
        :param str tenant:              The tenant code of the account (eg. tvv).
        :param str token_path:          The path where we can cache our token.
        """
        self._username = username
        self._password = password

        self._tenant = TENANTS.get(tenant)
        if self._tenant is None:
            raise Exception('Invalid tenant: %s' % tenant)

        self._token_path = token_path

        # Load existing account data
        self._account = AccountStorage()
        self._load_cache()

        # Generate device serial if we have none
        if not self._account.device_serial:
            self._account.device_serial = str(uuid.uuid4())
            self._save_cache()

    @staticmethod
    def _calculate_signature(url, payload):
        def p(payload):
            messageDigest = hashlib.sha256()
            bArr = payload.encode()
            messageDigest.update(bArr[:len(payload)])
            return messageDigest.digest()

        def b(encodeBase64):
            map = [65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104,
                   105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95]
            bArr = bytearray(((len(encodeBase64) + 2) // 3) * 4)
            length = len(encodeBase64) - (len(encodeBase64) % 3)
            i10 = 0
            i11 = 0
            while i10 < length:
                i12 = i10 + 1
                b10 = encodeBase64[i10]
                i13 = i12 + 1
                b11 = encodeBase64[i12]
                i14 = i13 + 1
                b12 = encodeBase64[i13]
                i15 = i11 + 1
                bArr[i11] = map[(b10 & 255) >> 2]
                i16 = i15 + 1
                bArr[i15] = map[((b10 & 3) << 4) | ((b11 & 255) >> 4)]
                i17 = i16 + 1
                bArr[i16] = map[((b11 & 15) << 2) | ((b12 & 255) >> 6)]
                i11 = i17 + 1
                bArr[i17] = map[b12 & 63]
                i10 = i14
            length2 = len(encodeBase64) - length
            if length2 != 1:
                if length2 == 2:
                    i18 = i10 + 1
                    b13 = encodeBase64[i10]
                    b14 = encodeBase64[i18]
                    i19 = i11 + 1
                    bArr[i11] = map[(b13 & 255) >> 2]
                    i20 = i19 + 1
                    bArr[i19] = map[((b13 & 3) << 4) | ((b14 & 255) >> 4)]
                    bArr[i20] = map[(b14 & 15) << 2]
                    bArr[i20 + 1] = 61
            else:
                b15 = encodeBase64[i10]
                i21 = i11 + 1
                bArr[i11] = map[(b15 & 255) >> 2]
                i22 = i21 + 1
                bArr[i21] = map[(b15 & 3) << 4]
                b16 = 61
                bArr[i22] = b16
                bArr[i22 + 1] = b16
            return bArr.decode('utf-8').replace("=", "")

        def L0(string, i10, i11, charset):
            z10 = i10 >= 0
            if z10:
                z11 = i11 >= i10
                if z11:
                    z12 = True
                    if i11 > len(string):
                        z12 = False
                    if z12:
                        substring = string[i10:i11]
                        return substring.encode(charset)
                    raise ValueError("endIndex > string.length: {} > {}".format(i11, len(string)))
                raise ValueError("endIndex < beginIndex: {} < {}".format(i11, i10))
            raise ValueError("beginIndex < 0: {}".format(i10))

        def v(bArr):
            try:
                mac = hmac.new(b'\x49\xa0\x56\xab\x6e\x76\xc1\x30\x69\xcf\x0a\xf2\x32\x8c\x8e\x3f\x3c\x07\x08\x9e\xf1\x10\xac\xaa', digestmod=hashlib.sha256)
                mac.update(bArr[:len(bArr)])
                return mac.digest()
            except (hashlib.NoSuchAlgorithmException, hmac.InvalidKeyException) as e10:
                raise ValueError(e10)

        payloadBytes = p(payload)
        payloadHash = b(payloadBytes)

        calendar = datetime.datetime.now(datetime.timezone.utc)
        time = str(round(calendar.timestamp()))

        urlAndHashAndTime = url + payloadHash + time

        bArr = L0(urlAndHashAndTime, 0, len(urlAndHashAndTime), "utf-8")
        payload2 = v(bArr)
        sig = b(payload2)

        return f'Client key=android.t3HFsLbBa08,time={time},sig={sig}'

    def get_tenant(self):
        """ Return the tenant information. """
        return self._tenant

    def login(self, force=False):
        """ Make a login request.

        :param bool force:              Force authenticating from scratch without cached tokens.

        :returns:                       An object containing tokens.
        :rtype: AccountStorage
        """
        # Check if credentials have changed
        new_hash = self._check_credentials_change()
        if new_hash:
            _LOGGER.debug('Credentials have changed, forcing a new login.')
            self._account.hash = new_hash
            force = True

        # Use cached token if it is still valid
        if not force and self._account.is_valid_token():
            return self._account

        if not self._account.sso_token:
            # We don't have a sso_token, so we need to request one
            # This challenge can be kept for a longer time
            self._account.sso_token = self._do_login(
                self._username,
                self._password,
                self._account.device_serial,
            )

        # Request a token
        self._account.jwt_token, self._account.sso_token = self._get_token(self._account.sso_token, self._account.device_serial)

        # Save the tokens we have in a cache
        self._save_cache()

        return self._account

    def _check_credentials_change(self):
        """ Check if credentials have changed.

        :return:                        The hash of the current credentials.
        :rtype: str
        """
        old_hash = self._account.hash
        new_hash = md5((self._username + ':' + self._password).encode('utf-8')).hexdigest()

        if new_hash != old_hash:
            return new_hash
        return None

    @staticmethod
    def _device_info(device_serial):
        return {
            "deviceModel": "samsung SM-G955F",
            "deviceOem": "samsung",
            "devicePrettyName": "Galaxy S8+",
            "deviceSerial": device_serial,
            "deviceType": "AndroidPhone",
            "environment": "",
            "featureLevel": 4,
            "osVersion": "Android 9 (28)",
            "brand": "tvv",
            "appVersion": "11.0",
        }

    def _do_login(self, username, password, device_serial):
        provision_data = self._get_provision_data(device_serial)
        ticket = self._get_ticket(device_serial, provision_data)

        url = 'https://m7login.solocoo.tv/login'
        data = {
            'ticket': ticket,
            'userInput': {
                'username': username,
                'password': password,
            },
        }
        signature = self._calculate_signature(url, json.dumps(data))

        response = util.http_post(url, data=data, headers={'Authorization': signature})
        result = json.loads(response.content)
        return result['ssoToken']

    def _get_provision_data(self, device_serial):
        response = util.http_post('https://tvapi.solocoo.tv/v1/provision', data=self._device_info(device_serial))
        result = json.loads(response.content)
        return result['session']['provisionData']

    def _get_ticket(self, device_serial, provision_data):
        url = 'https://m7login.solocoo.tv/login'
        data = {
            "deviceInfo": self._device_info(device_serial),
            "provisionData": provision_data
        }
        signature = self._calculate_signature(url, json.dumps(data))

        # Make request
        response = util.http_post(url,
                                  data=data,
                                  headers={
                                      'Authorization': signature,
                                      'Content-Type': 'application/json; charset=UTF-8',
                                  })
        result = json.loads(response.content)
        return result['ticket']

    def _get_token(self, sso_token, device_serial):
        data = self._device_info(device_serial)
        data['ssoToken'] = sso_token

        response = util.http_post('https://tvapi.solocoo.tv/v1/session', data=data)

        result = json.loads(response.content)
        return result['token'], result['ssoToken']

    def get_tokens(self):
        """ Return the tokens.

        :return:
        :rtype: AccountStorage
        """
        return self._account

    def logout(self):
        """ Clear the session tokens. """
        self._account.sso_token = None
        self._account.jwt_token = None

        self._save_cache()

    def list_entitlements(self):
        """ Fetch a list of entitlements on this account.

        :rtype: dict
        """
        try:
            reply = util.http_get(SOLOCOO_API + '/entitlements',
                                  headers={"Authorization": "Bearer " + self._account.jwt_token})
        except InvalidTokenException:
            self.login(True)
            reply = util.http_get(SOLOCOO_API + '/entitlements',
                                  headers={"Authorization": "Bearer " + self._account.jwt_token})

        entitlements = json.loads(reply.text)

        return dict(
            products=[product.get('id') for product in entitlements.get('products')],
            offers=[offer.get('id') for offer in entitlements.get('offers')],
            assets=[asset.get('id') for asset in entitlements.get('assets')],
        )

    def list_devices(self):
        """ Fetch a list of devices that are registered on this account.

        :rtype: list[dict]
        """
        reply = util.http_get(SOLOCOO_API + '/devices',
                              headers={"Authorization": "Bearer " + self._account.jwt_token})

        devices = json.loads(reply.text)
        return devices

    def remove_device(self, uid):
        """ Remove the specified device.

        :param str uid:                 The ID of the device to remove.
        """
        util.http_post(SOLOCOO_API + '/devices',
                       headers={"Authorization": "Bearer " + self._account.jwt_token},
                       data={
                           'delete': [uid]
                       })

    def _load_cache(self):
        """ Load tokens from cache """
        try:
            with open(self._token_path, 'r') as fdesc:
                self._account.__dict__ = json.loads(fdesc.read())  # pylint: disable=attribute-defined-outside-init
        except (IOError, TypeError, ValueError):
            _LOGGER.warning('We could not use the cache since it is invalid or non-existent.')

    def _save_cache(self):
        """ Store tokens in cache """
        with open(self._token_path, 'w') as fdesc:
            json.dump(self._account.__dict__, fdesc, indent=2)
