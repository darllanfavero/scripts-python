# -*- coding: utf-8 -*-
# GNU General Public License v3.0 (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, unicode_literals

import base64
import hashlib
import hmac
import logging
import re
import time
from json import dumps
from urllib.request import HTTPErrorProcessor, HTTPCookieProcessor, Request, build_opener

import requests

_LOGGER = logging.getLogger(__name__)


class NoRedirection(HTTPErrorProcessor):
    """Prevent urllib from following http redirects"""

    def http_response(self, request, response):
        return response

    https_response = http_response


def open_url(url, data=None, headers=None, method=None, cookiejar=None, follow_redirects=True):
    """Return a urllib http response"""

    opener_args = []
    if not follow_redirects:
        opener_args.append(NoRedirection)
    if cookiejar is not None:
        opener_args.append(HTTPCookieProcessor(cookiejar))
    opener = build_opener(*opener_args)

    if not headers:
        headers = {}
    req = Request(url, headers=headers)
    if data is not None:
        req.data = data

    if method is not None:
        req.get_method = lambda: method

    return opener.open(req)


class TokenResolver:
    """Get, refresh and cache tokens for VRT MAX API authentication."""

    _PLAYERTOKEN_URL = 'https://media-services-public.vrt.be/vualto-video-aggregator-web/rest/external/v2/tokens'

    def __init__(self):
        """Initialize Token Resolver class"""
        self._session = requests.Session()

    def get_playertoken(self):
        """Get a vrtPlayerToken"""
        headers = {'Content-Type': 'application/json'}
        playerinfo = self._generate_playerinfo()
        payload = {
            'playerInfo': playerinfo,
            'identityToken': None,
        }

        response = self._session.post(self._PLAYERTOKEN_URL, headers=headers, json=payload)
        playertoken = response.json().get('vrtPlayerToken')
        return playertoken

    @staticmethod
    def _generate_playerinfo():
        playerinfo = None
        data = None

        # Get data from player javascript
        player_url = 'https://player.vrt.be/vrtnu/js/player-lib.js'
        crypt_data = None
        while not crypt_data:
            response = open_url(player_url)
            if response:
                data = response.read().decode('utf-8')

                if data:
                    # Extract JWT key id and secret
                    crypt_rx = re.compile(r'atob\(\"(==[A-Za-z0-9+/]*)\"')
                    crypt_data = re.findall(crypt_rx, data)
                    if not crypt_data:
                        # Try redirect
                        redirect_rx = re.compile(r"((bootstrapper|drm-service)-[a-z0-9]{8}\.js)")
                        redirect_path = re.search(redirect_rx, data)
                        if redirect_path:
                            player_url = '{}/{}'.format(player_url[:player_url.rfind('/')], redirect_path.group(1))
                        else:
                            return playerinfo

        kid_source = crypt_data[0]
        secret_source = crypt_data[-1]
        kid = base64.b64decode(kid_source[::-1]).decode('utf-8')
        secret = base64.b64decode(secret_source[::-1]).decode('utf-8')

        # Extract player version
        player_version = '5.0.1-prod-2025-01-23T15:38:42'
        pv_rx = re.compile(r'playerVersion:\"(\S*)\"')
        match = re.search(pv_rx, data)
        if match:
            player_version = match.group(1)

        # Generate JWT
        segments = []
        header = {
            'alg': 'HS256',
            'kid': kid
        }
        payload = {
            'exp': time.time() + 1000,
            'platform': 'desktop',
            'app': {
                'type': 'browser',
                'name': 'Firefox',
                'version': '114.0'
            },
            'device': 'undefined (undefined)',
            'os': {
                'name': 'Linux',
                'version': 'x86_64'
            },
            'player': {
                'name': 'VRT web player',
                'version': player_version
            }
        }
        json_header = dumps(header).encode()
        json_payload = dumps(payload).encode()
        segments.append(base64.urlsafe_b64encode(json_header).decode('utf-8').replace('=', ''))
        segments.append(base64.urlsafe_b64encode(json_payload).decode('utf-8').replace('=', ''))
        signing_input = '.'.join(segments).encode()
        signature = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
        segments.append(base64.urlsafe_b64encode(signature).decode('utf-8').replace('=', ''))
        playerinfo = '.'.join(segments)
        return playerinfo
