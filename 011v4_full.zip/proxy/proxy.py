import argparse
import logging
import os
import re
import ssl
from http.server import BaseHTTPRequestHandler
from http.server import HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse

from curl_cffi import requests

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

SESSION = requests.Session(impersonate="chrome131")


class ProxyHTTPRequestHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.ca_cert_file = kwargs.pop('ca_cert_file')
        self.ca_key_file = kwargs.pop('ca_key_file')
        self.protocol_version = "HTTP/1.1"
        super().__init__(*args, **kwargs)

    def do_METHOD(self):
        # Parse the request URL
        host = self.headers.get('Host')
        if not host:
            self.send_error(400, "Host header is required")
            return

        # Handle CONNECT differently for HTTPS
        if self.command == 'CONNECT':
            self.handle_connect()
            return

        # Build the target URL for non-CONNECT methods
        path = self.path if self.path.startswith('http') else f"http://{host}{self.path}"

        # Log the request
        logger.info(f"{self.command} {path}")

        # Extract request headers
        headers = {k: v for k, v in self.headers.items() if k.lower() not in ['host', 'content-length', 'user-agent']}

        # Read request body if present
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else None

        try:
            response = SESSION.request(
                method=self.command,
                url=path,
                headers=headers,
                data=body,
                verify=False,
                allow_redirects=False,
                timeout=5  # Ensuring timeout to detect dead connections
            )
            logger.info(f"HTTP {self.command} {path} {response.status_code} {response.reason}")

            self.send_response(response.status_code)
            for header, value in response.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-length', 'content-encoding']:
                    self.send_header(header, value)
            self.send_header('Content-Length', str(len(response.content)))
            self.end_headers()
            self.wfile.write(response.content)

            # Ensure connection is closed if the server requests it
            if response.headers.get("Connection", "").lower() == "close":
                logger.info("Server requested connection close")
                self.close_connection = True

        except Exception as e:
            logger.error(f"Error handling request: {e}")
            self.send_error(500, f"Error: {str(e)}")

    def handle_connect(self):
        """Handle HTTPS CONNECT method without establishing direct TLS connection to server"""
        # Acknowledge the connection to the client
        self.send_response(200, 'Connection Established')
        self.end_headers()

        # Create an SSL context with our pre-generated certificate
        context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        context.load_cert_chain(certfile=self.ca_cert_file, keyfile=self.ca_key_file)

        # Store the original connection
        original_connection = self.connection

        try:
            # Create a TLS connection with the client
            self.connection = context.wrap_socket(self.connection, server_side=True)

            # Now handle the TLS-encrypted HTTP requests without making TLS connection to server
            # Read the HTTP request from the client
            self.rfile = self.connection.makefile('rb', self.rbufsize)
            self.wfile = self.connection.makefile('wb', self.wbufsize)

            # Process HTTPS requests in a loop until client or server terminates the connection
            while True:
                # Parse the request line
                request_line = self.rfile.readline().decode('iso-8859-1')
                if not request_line:
                    logger.info("Client closed connection")
                    break  # Break the loop if client closes the connection

                request_line = request_line.rstrip('\r\n')
                words = request_line.split()
                if len(words) == 0:
                    logger.info("Empty request line")
                    break  # Break the loop on empty request

                if len(words) < 3:
                    logger.error("Invalid HTTP request")
                    break  # Break the loop on invalid HTTP request

                method, path, version = words

                # Parse HTTP headers
                headers = {}
                content_length = 0

                while True:
                    line = self.rfile.readline().decode('iso-8859-1')
                    if line in ['\r\n', '\n', '']:
                        break

                    header_line = line.strip()
                    if ':' in header_line:
                        key, value = header_line.split(':', 1)
                        headers[key.strip()] = value.strip()

                        if key.strip().lower() == 'content-length':
                            content_length = int(value.strip())

                # Read the request body
                body = self.rfile.read(content_length) if content_length > 0 else None

                # Get the host from the headers, or extract from the path if it's absolute
                host = headers.get('Host')
                if not host and path.startswith('http'):
                    parsed_url = urlparse(path)
                    host = parsed_url.netloc

                # Build the full URL if the path is not absolute
                if not path.startswith('http'):
                    url = f"https://{host}{path}"
                else:
                    url = path

                try:
                    response = SESSION.request(
                        method=method,
                        url=url,
                        headers={k: v for k, v in headers.items() if k.lower() not in ['host', 'content-length', 'user-agent']},
                        data=body,
                        verify=False,
                        allow_redirects=False,
                        timeout=5,  # Add timeout to detect server disconnection
                    )
                    logger.info(f"HTTPS {method} {url} {response.status_code} {response.reason}")

                    # Ugly Workaround for Beesport
                    if '.m3u8' in url:
                        if re.search(br'1\.\d{9}s$', response.content):
                            logger.info('Matched with 1.999999999s, sending UNAUTHORIZED')
                            # Return 403 so o11 retries the manifest
                            self.wfile.write(b"HTTP/1.1 403 Unauthorized\r\nContent-Length: 0\r\n\r\n")
                            self.wfile.flush()
                            continue

                    # Prepare the response to send back to the client
                    response_line = f"HTTP/1.1 {response.status_code} {response.reason}\r\n"
                    self.wfile.write(response_line.encode('iso-8859-1'))

                    # Send response headers
                    for header, value in response.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-length', 'content-encoding']:
                            header_line = f"{header}: {value}\r\n"
                            self.wfile.write(header_line.encode('iso-8859-1'))
                    self.wfile.write(f"Content-Length: {len(response.content)}\r\n".encode('iso-8859-1'))

                    # End of headers
                    self.wfile.write(b"\r\n")

                    # Send response body
                    self.wfile.write(response.content)
                    self.wfile.flush()

                except requests.RequestsError as e:
                    logger.error(f"Request error: {e}")

                    # Send error response to client
                    error_response = f"HTTP/1.1 502 Bad Gateway\r\nContent-Type: text/plain\r\n\r\nError connecting to server: {str(e)}"
                    self.wfile.write(error_response.encode('iso-8859-1'))
                    self.wfile.flush()
                    break  # Exit the loop on request error

                except Exception as e:
                    logger.error(f"Error handling HTTPS request: {e}")

                    # Send error response to client
                    error_response = f"HTTP/1.1 500 Internal Server Error\r\nContent-Type: text/plain\r\n\r\nProxy error: {str(e)}"
                    self.wfile.write(error_response.encode('iso-8859-1'))
                    self.wfile.flush()
                    break  # Exit the loop on any error

        except ssl.SSLError as e:
            logger.error(f"SSL error when wrapping socket: {e}")
        except ConnectionError as e:
            logger.error(f"Connection error: {e}")
        except Exception as e:
            logger.error(f"Error in CONNECT handling: {e}")
        finally:
            # Clean up resources
            logger.info("Closing HTTPS connection")
            self.connection.close()
            original_connection.close()

    # Handle all HTTP methods
    do_GET = do_METHOD
    do_POST = do_METHOD
    do_PUT = do_METHOD
    do_DELETE = do_METHOD
    do_HEAD = do_METHOD
    do_OPTIONS = do_METHOD
    do_PATCH = do_METHOD
    do_CONNECT = do_METHOD


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""
    daemon_threads = True  # This ensures threads are cleaned up on exit

    def __init__(self, server_address, RequestHandlerClass, ca_cert_file, ca_key_file):
        self.ca_cert_file = ca_cert_file
        self.ca_key_file = ca_key_file
        super().__init__(server_address, RequestHandlerClass)

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass."""
        self.RequestHandlerClass(request, client_address, self, ca_cert_file=self.ca_cert_file, ca_key_file=self.ca_key_file)


def run_proxy(host='localhost', port=1080, ca_cert_file='keys/ca-cert.pem', ca_key_file='keys/ca-key.pem'):
    # Check if certificate and key files exist
    if not os.path.exists(ca_cert_file) or not os.path.exists(ca_key_file):
        logger.error(f"Certificate file ({ca_cert_file}) or key file ({ca_key_file}) not found.")
        return

    # Create the server
    server = ThreadedHTTPServer((host, port), ProxyHTTPRequestHandler, ca_cert_file, ca_key_file)

    print(f"Proxy server is running at http://{host}:{port}")
    print(f"Using CA Certificate: {ca_cert_file}")
    print(f"Using CA Private Key: {ca_key_file}")

    # Run the server
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Shutting down the proxy server...")
        server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='HTTP/HTTPS Proxy with curl-cffi Integration')
    parser.add_argument('--host', default='localhost', help='Host to bind the proxy server to')
    parser.add_argument('--port', type=int, default=1080, help='Port to bind the proxy server to')
    parser.add_argument('--ca-cert', default='keys/ca-cert.pem', help='Path to CA certificate file')
    parser.add_argument('--ca-key', default='keys/ca-key.pem', help='Path to CA private key file')
    args = parser.parse_args()

    run_proxy(args.host, args.port, args.ca_cert, args.ca_key)
